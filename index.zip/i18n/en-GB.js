module.exports = {
    translation : {
        'GREETING' : [ // test all these individually to make sure they flow into the question correctly
            'On your marks <break time="1s"/> set <break time="1s"/> ',
            'Let\'s go! ',
            'Here goes! ',
            'Get ready! ',
            'Here we go! ',
            'Ready. Set. Go! ',
            'Hold tight! ',
            'Three. two. one! ',
        ],
    }
}